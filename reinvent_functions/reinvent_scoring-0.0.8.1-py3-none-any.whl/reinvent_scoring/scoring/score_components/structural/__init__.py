from reinvent_scoring.scoring.score_components.structural.azdock import AZdock
from reinvent_scoring.scoring.score_components.structural.dockstream import DockStream
