

class ScaffoldMemoryFieldsEnum:
    SMILES = "SMILES"
    SCAFFOLD = "Scaffold"


