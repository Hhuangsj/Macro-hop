from setuptools import setup, find_packages

setup(
    name='reinvent_scoring',
    version='0.0.8.1',
    description='none',
    keywords='any',
    packages=find_packages(),
    install_requires=[
        'numpy',
        'matplotlib'
    ],
        author='sjhuang',
)

